from flask_sqlalchemy import SQLAlchemy as SQL
db = SQL()
